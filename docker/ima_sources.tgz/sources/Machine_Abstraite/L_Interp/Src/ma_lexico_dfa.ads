package ma_lexico_DFA is
aflex_debug : boolean := false;
yytext_ptr : integer; -- points to start of yytext in buffer

-- yy_ch_buf has to be 2 characters longer than YY_BUF_SIZE because we need
-- to put in 2 end-of-buffer characters (this is explained where it is
-- done) at the end of yy_ch_buf
YY_READ_BUF_SIZE : constant integer :=  8192;
YY_BUF_SIZE : constant integer := YY_READ_BUF_SIZE * 2; -- size of input buffer
type unbounded_character_array is array(integer range <>) of character;
subtype ch_buf_type is unbounded_character_array(0..YY_BUF_SIZE + 1);
yy_ch_buf : ch_buf_type;
yy_cp, yy_bp : integer;

-- yy_hold_char holds the character lost when yytext is formed
yy_hold_char : character;
yy_c_buf_p : integer;   -- points to current character in buffer

function YYText return string;
function YYLength return integer;
procedure YY_DO_BEFORE_ACTION;
--These variables are needed between calls to YYLex.
yy_init : boolean := true; -- do we need to initialize YYLex?
yy_start : integer := 0; -- current start state number
subtype yy_state_type is integer;
yy_last_accepting_state : yy_state_type;
yy_last_accepting_cpos : integer;
subtype short is integer range -32768..32767;

yy_accept : constant array(0..52) of short :=
    (   0,
        0,    0,   20,   18,    2,    1,   18,   18,   12,   13,
       18,   14,   18,    5,   17,    2,    3,    0,   15,    0,
        0,    8,    8,    0,    4,    6,    5,    2,    3,   15,
        0,    7,    7,    9,    9,    0,    0,    0,   16,   10,
        0,    0,    0,    0,   11,    0,   10,    0,    0,    0,
       10,    0
    ) ;

yy_ec : constant array(CHARACTER) of short :=
    (   0,
        1,    1,    1,    1,    1,    1,    1,    1,    2,    3,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    2,    1,    4,    5,    1,    1,    1,    1,    6,
        7,    1,    8,    9,   10,   11,    1,   12,   13,   14,
       14,   14,   14,   14,   14,   14,   14,   15,   16,    1,
        1,    1,    1,    1,   17,   17,   17,   17,   18,   17,
       19,   19,   19,   19,   19,   19,   19,   19,   19,   19,
       19,   19,   19,   19,   19,   19,   19,   19,   19,   19,
        1,    1,    1,    1,   20,    1,   17,   17,   17,   17,

       18,   17,   19,   19,   19,   19,   19,   21,   19,   22,
       19,   23,   19,   19,   19,   19,   24,   19,   19,   25,
       19,   19,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,

        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1
    ) ;

yy_meta : constant array(0..25) of short :=
    (   0,
        1,    1,    2,    1,    1,    1,    1,    3,    1,    3,
        4,    5,    5,    5,    1,    1,    6,    7,    8,    8,
        8,    8,    8,    8,    4
    ) ;

yy_base : constant array(0..64) of short :=
    (   0,
        0,    0,  148,  149,  149,  149,  143,   18,  149,  149,
       21,  149,   24,   29,  149,    0,    0,  142,  140,   32,
       35,   28,   39,  114,   42,   45,   48,    0,    0,  126,
      123,   40,   41,   52,   56,   56,   59,   94,   96,   74,
        0,   62,   19,    0,  149,   61,   66,   53,   74,   73,
       76,  149,   90,   98,  103,  108,  113,  118,  120,  121,
      128,  134,  135,  140
    ) ;

yy_def : constant array(0..64) of short :=
    (   0,
       52,    1,   52,   52,   52,   52,   53,   52,   52,   52,
       52,   52,   52,   52,   52,   54,   55,   53,   52,   52,
       52,   56,   56,   52,   52,   52,   52,   54,   55,   52,
       57,   58,   58,   59,   59,   52,   52,   52,   52,   60,
       61,   52,   62,   63,   52,   52,   52,   63,   64,   52,
       52,    0,   52,   52,   52,   52,   52,   52,   52,   52,
       52,   52,   52,   52
    ) ;

yy_nxt : constant array(0..174) of short :=
    (   0,
        4,    5,    6,    7,    8,    9,   10,   11,   12,   13,
        4,   14,   14,   14,   15,   16,   17,   17,   17,    4,
       17,   17,   17,   17,   17,   20,   46,   21,   46,   22,
       23,   23,   25,   25,   25,   26,   26,   26,   36,   24,
       27,   27,   27,   32,   33,   33,   34,   35,   35,   36,
       36,   36,   37,   25,   25,   25,   26,   26,   26,   27,
       27,   27,   36,   52,   37,   52,   36,   40,   40,   40,
       41,   41,   47,   47,   47,   49,   37,   47,   47,   47,
       52,   50,   45,   50,   51,   51,   51,   51,   51,   51,
       18,   43,   18,   18,   18,   18,   18,   18,   28,   31,

       28,   28,   28,   28,   28,   28,   29,   29,   29,   29,
       29,   23,   23,   31,   42,   31,   31,   31,   31,   31,
       31,   33,   33,   35,   35,   40,   39,   40,   44,   31,
       44,   44,   44,   44,   44,   44,   47,   38,   47,   48,
       48,   48,   51,   31,   51,   30,   19,   52,    3,   52,
       52,   52,   52,   52,   52,   52,   52,   52,   52,   52,
       52,   52,   52,   52,   52,   52,   52,   52,   52,   52,
       52,   52,   52,   52
    ) ;

yy_chk : constant array(0..174) of short :=
    (   0,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
        1,    1,    1,    1,    1,    8,   43,    8,   43,    8,
        8,    8,   11,   11,   11,   13,   13,   13,   22,    8,
       14,   14,   14,   20,   20,   20,   21,   21,   21,   23,
       32,   33,   22,   25,   25,   25,   26,   26,   26,   27,
       27,   27,   34,   23,   32,   33,   35,   36,   36,   36,
       37,   37,   46,   46,   46,   48,   34,   47,   47,   47,
       35,   49,   42,   49,   50,   50,   50,   51,   51,   51,
       53,   40,   53,   53,   53,   53,   53,   53,   54,   39,

       54,   54,   54,   54,   54,   54,   55,   55,   55,   55,
       55,   56,   56,   57,   38,   57,   57,   57,   57,   57,
       57,   58,   58,   59,   59,   60,   31,   60,   61,   30,
       61,   61,   61,   61,   61,   61,   62,   24,   62,   63,
       63,   63,   64,   19,   64,   18,    7,    3,   52,   52,
       52,   52,   52,   52,   52,   52,   52,   52,   52,   52,
       52,   52,   52,   52,   52,   52,   52,   52,   52,   52,
       52,   52,   52,   52
    ) ;

end ma_lexico_DFA;

