
-- corps du paquetage d'analyse syntaxique

with Ada.TEXT_IO, MA_SYNTAX_SHIFT_REDUCE, MA_SYNTAX_GOTO, TYPES_BASE,
     MA_DETIQ, PSEUDO_CODE;
use  Ada.TEXT_IO, MA_SYNTAX_SHIFT_REDUCE, MA_SYNTAX_GOTO, TYPES_BASE,
     MA_DETIQ, PSEUDO_CODE;

package body MA_SYNTAX is

  use MA_Lexico, MA_Syntax_Tokens;

  function R(n : Num_reg_banalise) return banalise is
  begin
    return banalise'val(n + banalise'pos(banalise'first));
  end R;

  function creation_direct(n : Num_reg_banalise) return operande is
  begin
    return le_registre(R(n));
  end creation_direct;

  procedure yyerror(text : in string) is
  -- affiche un message d'erreur
  begin
    put_line ("LIGNE " & positive'image(num_ligne) &
              " -- erreur syntaxique");
  end yyerror;

  nbi : Natural;

  -- yyparse
procedure YYParse is

   -- Rename User Defined Packages to Internal Names.
    package yy_goto_tables         renames
      Ma_Syntax_Goto;
    package yy_shift_reduce_tables renames
      Ma_Syntax_Shift_Reduce;
    package yy_tokens              renames
      Ma_Syntax_Tokens;

   use yy_tokens, yy_goto_tables, yy_shift_reduce_tables;

   procedure yyerrok;
   procedure yyclearin;


   package yyd is

       -- Is Debugging option on or off
        DEBUG : constant boolean := FALSE;

    end yyd;


    function goto_state
      (state : yy.parse_state;
       sym   : nonterminal) return yy.parse_state;

    function parse_action
      (state : yy.parse_state;
       t     : yy_tokens.token) return integer;

    pragma inline(goto_state, parse_action);


    function goto_state(state : yy.parse_state;
                        sym   : nonterminal) return yy.parse_state is
        index : integer;
    begin
        index := goto_offset(state);
        while  integer(goto_matrix(index).nonterm) /= sym loop
            index := index + 1;
        end loop;
        return integer(goto_matrix(index).newstate);
    end goto_state;


    function parse_action(state : yy.parse_state;
                          t     : yy_tokens.token) return integer is
        index      : integer;
        tok_pos    : integer;
        default    : constant integer := -1;
    begin
        tok_pos := yy_tokens.token'pos(t);
        index   := shift_reduce_offset(state);
        while integer(shift_reduce_matrix(index).t) /= tok_pos and then
              integer(shift_reduce_matrix(index).t) /= default
        loop
            index := index + 1;
        end loop;
        return integer(shift_reduce_matrix(index).act);
    end parse_action;

-- error recovery stuff

    procedure handle_error is
      temp_action : integer;
    begin

      if yy.error_flag = 3 then -- no shift yet, clobber input.
      if yyd.debug then
          Ada.Text_IO.put_line("Ayacc.YYParse: Error Recovery Clobbers " &
                   yy_tokens.token'image(yy.input_symbol));
      end if;
        if yy.input_symbol = yy_tokens.end_of_input then  -- don't discard,
        if yyd.debug then
            Ada.Text_IO.put_line("Ayacc.YYParse: Can't discard END_OF_INPUT, quiting...");
        end if;
        raise yy_tokens.syntax_error;
        end if;

            yy.look_ahead := true;   -- get next token
        return;                  -- and try again...
    end if;

    if yy.error_flag = 0 then -- brand new error
        yyerror("Syntax Error");
    end if;

    yy.error_flag := 3;

    -- find state on stack where error is a valid shift --

    if yyd.debug then
        Ada.Text_IO.put_line("Ayacc.YYParse: Looking for state with error as valid shift");
    end if;

    loop
        if yyd.debug then
          Ada.Text_IO.put_line("Ayacc.YYParse: Examining State " &
               yy.parse_state'image(yy.state_stack(yy.tos)));
        end if;
        temp_action := parse_action(yy.state_stack(yy.tos), error);

            if temp_action >= yy.first_shift_entry then
                if yy.tos = yy.stack_size then
                    Ada.Text_IO.put_line(" Stack size exceeded on state_stack");
                    raise yy_Tokens.syntax_error;
                end if;
                yy.tos := yy.tos + 1;
                yy.state_stack(yy.tos) := temp_action;
                exit;
            end if;

        Decrement_Stack_Pointer :
        begin
          yy.tos := yy.tos - 1;
        exception
          when Constraint_Error =>
            yy.tos := 0;
        end Decrement_Stack_Pointer;

        if yy.tos = 0 then
          if yyd.debug then
            Ada.Text_IO.put_line("Ayacc.YYParse: Error recovery popped entire stack, aborting...");
          end if;
          raise yy_tokens.syntax_error;
        end if;
    end loop;

    if yyd.debug then
        Ada.Text_IO.put_line("Ayacc.YYParse: Shifted error token in state " &
              yy.parse_state'image(yy.state_stack(yy.tos)));
    end if;

    end handle_error;

   -- print debugging information for a shift operation
   procedure shift_debug(state_id: yy.parse_state; lexeme: yy_tokens.token) is
   begin
       Ada.Text_IO.put_line("Ayacc.YYParse: Shift "& yy.parse_state'image(state_id)&" on input symbol "&
               yy_tokens.token'image(lexeme) );
   end;

   -- print debugging information for a reduce operation
   procedure reduce_debug(rule_id: rule; state_id: yy.parse_state) is
   begin
       Ada.Text_IO.put_line("Ayacc.YYParse: Reduce by rule "&rule'image(rule_id)&" goto state "&
               yy.parse_state'image(state_id));
   end;

   -- make the parser believe that 3 valid shifts have occured.
   -- used for error recovery.
   procedure yyerrok is
   begin
       yy.error_flag := 0;
   end yyerrok;

   -- called to clear input symbol that caused an error.
   procedure yyclearin is
   begin
       -- yy.input_symbol := yylex;
       yy.look_ahead := true;
   end yyclearin;


begin
    -- initialize by pushing state 0 and getting the first input symbol
    yy.state_stack(yy.tos) := 0;


    loop

        yy.index := shift_reduce_offset(yy.state_stack(yy.tos));
        if integer(shift_reduce_matrix(yy.index).t) = yy.default then
            yy.action := integer(shift_reduce_matrix(yy.index).act);
        else
            if yy.look_ahead then
                yy.look_ahead   := false;

                yy.input_symbol := yylex;
            end if;
            yy.action :=
             parse_action(yy.state_stack(yy.tos), yy.input_symbol);
        end if;


        if yy.action >= yy.first_shift_entry then  -- SHIFT

            if yyd.debug then
                shift_debug(yy.action, yy.input_symbol);
            end if;

            -- Enter new state
            if yy.tos = yy.stack_size then
                Ada.Text_IO.put_line(" Stack size exceeded on state_stack");
                raise yy_Tokens.syntax_error;
            end if;
            yy.tos := yy.tos + 1;
            yy.state_stack(yy.tos) := yy.action;
              yy.value_stack(yy.tos) := yylval;

        if yy.error_flag > 0 then  -- indicate a valid shift
            yy.error_flag := yy.error_flag - 1;
        end if;

            -- Advance lookahead
            yy.look_ahead := true;

        elsif yy.action = yy.error_code then       -- ERROR

            handle_error;

        elsif yy.action = yy.accept_code then
            if yyd.debug then
                Ada.Text_IO.put_line("Ayacc.YYParse: Accepting Grammar...");
            end if;
            exit;

        else -- Reduce Action

            -- Convert action into a rule
            yy.rule_id  := -1 * yy.action;

            -- Execute User Action
            -- user_action(yy.rule_id);


                case yy.rule_id is

when  1 =>
--#line  101
 
yyval := (nt_list_ligne, null, null); 

when  2 =>
--#line  103
 if 
yy.value_stack(yy.tos-1).val_list_ligne = null then
         
yyval := 
yy.value_stack(yy.tos);
       elsif 
yy.value_stack(yy.tos).val_list_ligne = null then
         
yyval := 
yy.value_stack(yy.tos-1);
       else
         changer_suivant(
yy.value_stack(yy.tos-1).val_dern_ligne, 
yy.value_stack(yy.tos).val_list_ligne);
         
yyval := (nt_list_ligne, 
yy.value_stack(yy.tos-1).val_list_ligne, 
yy.value_stack(yy.tos).val_dern_ligne);
       end if; 

when  3 =>
--#line  115
 
yyval := 
yy.value_stack(yy.tos-1); 

when  4 =>
--#line  117
 declare
          L : ligne := creation(null, 
yy.value_stack(yy.tos-1).val_instr, "",
                                null, 
yy.value_stack(yy.tos-1).num_ligne_instr);
        begin
          nbi := nbi + 1;
          if 
yy.value_stack(yy.tos-2).val_list_ligne = null then
            
yyval := (nt_list_ligne, L, L);
          else
            changer_suivant(
yy.value_stack(yy.tos-2).val_dern_ligne, L);
            
yyval := (nt_list_ligne, 
yy.value_stack(yy.tos-2).val_list_ligne, L);
          end if;
        end; 

when  5 =>
--#line  133
 
yyval := (nt_list_ligne, null, null); 

when  6 =>
--#line  135
 if 
yy.value_stack(yy.tos-1).val_list_ligne = null then
          
yyval := 
yy.value_stack(yy.tos);
        else
          changer_suivant(
yy.value_stack(yy.tos-1).val_dern_ligne, 
yy.value_stack(yy.tos).val_list_ligne);
          
yyval := (nt_list_ligne, 
yy.value_stack(yy.tos-1).val_list_ligne, 
yy.value_stack(yy.tos).val_dern_ligne);
        end if; 

when  7 =>
--#line  145
 declare
          E : etiq;
          L : ligne := creation(null, null, "", null, 
yy.value_stack(yy.tos-1).num_ligne_etiq);
        begin
          ins_def_etiq(acces_string(
yy.value_stack(yy.tos-1).val_etiq), E);
          changer_etiq(L, E);
          changer_ligne_def(E, L);
          
yyval := (nt_list_ligne, L, L);
        exception
          when MA_double_defetiq =>
            put_line("ERREUR ligne" & positive'image(
yy.value_stack(yy.tos-1).num_ligne_etiq) &
                     " : etiquette " & acces_string(
yy.value_stack(yy.tos-1).val_etiq) &
                     " deja definie !!");
            raise MA_double_defetiq;
          end; 

when  8 =>
--#line  164
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_autre,
               creation_inst2(code_LOAD, 
yy.value_stack(yy.tos-2).val_adressage,
                                         creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  9 =>
--#line  168
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_autre,
               creation_inst2(code_STORE, creation_direct(
yy.value_stack(yy.tos-2).num_regb),
                                          
yy.value_stack(yy.tos).val_adressage)); 

when  10 =>
--#line  172
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_autre,
               creation_inst2(code_LEA, 
yy.value_stack(yy.tos-2).val_adressage,
                                        creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  11 =>
--#line  176
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
               creation_inst1(code_PEA, 
yy.value_stack(yy.tos).val_adressage)); 

when  12 =>
--#line  179
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
               creation_inst1(code_ADDSP, creation_op_entier(
yy.value_stack(yy.tos).val_ent))); 

when  13 =>
--#line  182
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
               creation_inst1(code_SUBSP, creation_op_entier(
yy.value_stack(yy.tos).val_ent))); 

when  14 =>
--#line  185
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_codop,
               creation_inst2(
yy.value_stack(yy.tos-3).val_code, 
yy.value_stack(yy.tos-2).val_adressage,
                                           creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  15 =>
--#line  189
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_codop,
               creation_inst2(
yy.value_stack(yy.tos-3).val_code, 
yy.value_stack(yy.tos-2).val_adressage,
                                           creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  16 =>
--#line  193
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_codop,
               creation_inst2(
yy.value_stack(yy.tos-3).val_code, 
yy.value_stack(yy.tos-2).val_adressage,
                                           creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  17 =>
--#line  197
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_codop,
               creation_inst1(
yy.value_stack(yy.tos-1).val_code, creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  18 =>
--#line  200
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-3).num_ligne_autre,
                         creation_inst2(code_NEW,
                                        
yy.value_stack(yy.tos-2).val_adressage,
                                        creation_direct (
yy.value_stack(yy.tos).num_regb))); 

when  19 =>
--#line  205
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
                         creation_inst1(code_DEL,
                                        creation_direct(
yy.value_stack(yy.tos).num_regb))); 

when  20 =>
--#line  209
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_codop,
                 creation_inst1(
yy.value_stack(yy.tos-1).val_code, 
yy.value_stack(yy.tos).val_adressage)); 

when  21 =>
--#line  212
 
yyval := (nt_instr, 
yy.value_stack(yy.tos).num_ligne_codop, creation_inst0(
yy.value_stack(yy.tos).val_code)); 

when  22 =>
--#line  214
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
               creation_inst1(code_WSTR, creation_op_chaine(
yy.value_stack(yy.tos).val_chaine))); 

when  23 =>
--#line  217
 
yyval := (nt_instr, 
yy.value_stack(yy.tos-1).num_ligne_autre,
               creation_inst1(code_TSTO, creation_op_entier(
yy.value_stack(yy.tos).val_ent))); 

when  24 =>
--#line  223
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_ADD); 

when  25 =>
--#line  225
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SUB); 

when  26 =>
--#line  227
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_OPP); 

when  27 =>
--#line  229
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_MUL); 

when  28 =>
--#line  231
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_CMP); 

when  29 =>
--#line  236
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_QUO); 

when  30 =>
--#line  238
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_REM); 

when  31 =>
--#line  240
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_FLOAT); 

when  32 =>
--#line  245
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_DIV); 

when  33 =>
--#line  247
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_INT); 

when  34 =>
--#line  249
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_FMA); 

when  35 =>
--#line  254
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SEQ); 

when  36 =>
--#line  256
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SNE); 

when  37 =>
--#line  258
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SGT); 

when  38 =>
--#line  260
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SLT); 

when  39 =>
--#line  262
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SGE); 

when  40 =>
--#line  264
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SLE); 

when  41 =>
--#line  266
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SOV); 

when  42 =>
--#line  268
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_PUSH); 

when  43 =>
--#line  270
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_POP); 

when  44 =>
--#line  272
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SHL); 

when  45 =>
--#line  274
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SHR); 

when  46 =>
--#line  279
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_RTS); 

when  47 =>
--#line  281
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_RINT); 

when  48 =>
--#line  283
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_RUTF8); 

when  49 =>
--#line  285
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_RFLOAT); 

when  50 =>
--#line  287
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_WINT); 

when  51 =>
--#line  289
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_WUTF8); 

when  52 =>
--#line  291
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_WFLOAT); 

when  53 =>
--#line  293
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_WFLOATX); 

when  54 =>
--#line  295
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_WNL); 

when  55 =>
--#line  297
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SCLK); 

when  56 =>
--#line  299
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_CLK); 

when  57 =>
--#line  301
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SETROUND_TONEAREST); 

when  58 =>
--#line  303
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SETROUND_UPWARD); 

when  59 =>
--#line  305
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SETROUND_DOWNWARD); 

when  60 =>
--#line  307
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_SETROUND_TOWARDZERO); 

when  61 =>
--#line  309
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_HALT); 

when  62 =>
--#line  311
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_ERROR); 

when  63 =>
--#line  316
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BRA); 

when  64 =>
--#line  318
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BEQ); 

when  65 =>
--#line  320
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BNE); 

when  66 =>
--#line  322
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BGT); 

when  67 =>
--#line  324
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BLT); 

when  68 =>
--#line  326
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BGE); 

when  69 =>
--#line  328
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BLE); 

when  70 =>
--#line  330
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BOV); 

when  71 =>
--#line  332
 
yyval := (nt_codop, 
yy.value_stack(yy.tos).num_ligne_autre, code_BSR); 

when  72 =>
--#line  337
 
yyval := 
yy.value_stack(yy.tos); 

when  73 =>
--#line  339
 
yyval := 
yy.value_stack(yy.tos); 

when  74 =>
--#line  341
 
yyval := (nt_adressage, L_Op_Null); 

when  75 =>
--#line  343
 declare
            E : etiq;
         begin
            ins_util_etiq (acces_string (
yy.value_stack(yy.tos).val_etiq), E);
            
yyval := (nt_adressage,
                   creation_op_etiq(E));
         end;
      

when  76 =>
--#line  355
 
yyval := 
yy.value_stack(yy.tos); 

when  77 =>
--#line  357
 
yyval := (nt_adressage,creation_direct(
yy.value_stack(yy.tos).num_regb)); 

when  78 =>
--#line  359
 
yyval := 
yy.value_stack(yy.tos); 

when  79 =>
--#line  364
 
yyval := 
yy.value_stack(yy.tos); 

when  80 =>
--#line  366
 
yyval := (nt_adressage,creation_direct(
yy.value_stack(yy.tos).num_regb)); 

when  81 =>
--#line  368
 
yyval := (nt_adressage, creation_op_flottant(Flottant(Creation("0.0")),
yy.value_stack(yy.tos).val_Flot_MA)); 

when  82 =>
--#line  373
 
yyval := (nt_adressage,
               creation_op_indirect(deplacement(
yy.value_stack(yy.tos-3).val_ent), 
yy.value_stack(yy.tos-1).val_reg)); 

when  83 =>
--#line  376
 
yyval := (nt_adressage,
               creation_op_indexe(deplacement(
yy.value_stack(yy.tos-5).val_ent), 
yy.value_stack(yy.tos-3).val_reg,
                                  R(
yy.value_stack(yy.tos-1).num_regb))); 

when  84 =>
--#line  383
 
yyval := (nt_adressage,creation_op_entier(
yy.value_stack(yy.tos).val_ent)); 

when  85 =>
--#line  385
 
yyval := (nt_adressage,creation_op_entier(
yy.value_stack(yy.tos).val_ent)); 

when  86 =>
--#line  390
 
yyval := (nt_reg, R(
yy.value_stack(yy.tos).num_regb)); 

when  87 =>
--#line  392
 
yyval := (nt_reg, LB); 

when  88 =>
--#line  394
 
yyval := (nt_reg, GB); 

when  89 =>
--#line  396
 
yyval := (nt_reg, SP); 

                    when others => null;
                end case;


            -- Pop RHS states and goto next state
            yy.tos      := yy.tos - rule_length(yy.rule_id) + 1;
            if yy.tos > yy.stack_size then
                Ada.Text_IO.put_line(" Stack size exceeded on state_stack");
                raise yy_Tokens.syntax_error;
            end if;
            yy.state_stack(yy.tos) := goto_state(yy.state_stack(yy.tos-1) ,
                                 get_lhs_rule(yy.rule_id));

              yy.value_stack(yy.tos) := yyval;

            if yyd.debug then
                reduce_debug(yy.rule_id,
                    goto_state(yy.state_stack(yy.tos - 1),
                               get_lhs_rule(yy.rule_id)));
            end if;

        end if;


    end loop;


end yyparse;

  procedure analyser_construire_liste_lignes(L : out ligne;
                                             nblignes : out natural;
                                             nbinsts : out natural) is
  begin
    nbi := 0;
    yyparse;
    L := yyval.val_list_ligne;
    nblignes := num_ligne - 1;
    nbinsts := nbi;
  end analyser_construire_liste_lignes;

end MA_SYNTAX;
