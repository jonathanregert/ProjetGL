with Ma_Syntax_Tokens;
with Ma_Syntax_Goto;
package Ma_Syntax_Shift_Reduce is

    type Small_Integer is range -32_000 .. 32_000;

    type Shift_Reduce_Entry is record
        T   : Small_Integer;
        Act : Small_Integer;
    end record;
    pragma Pack(Shift_Reduce_Entry);

    subtype Row is Integer range -1 .. Integer'Last;

  --pragma suppress(index_check);

    type Shift_Reduce_Array is array (Row  range <>) of Shift_Reduce_Entry;

    Shift_Reduce_Matrix : constant Shift_Reduce_Array :=
        ( (-1,-1) -- Dummy Entry

-- state  0
,(-1,-1)
-- state  1
,( 0,-3001),(-1,-5)
-- state  2
,( 2, 70)
,( 3, 21),( 11, 5),( 12, 6),( 13, 7)
,( 14, 8),( 15, 40),( 16, 41),( 17, 9)
,( 18, 10),( 19, 22),( 20, 23),( 21, 24)
,( 22, 25),( 23, 27),( 24, 26),( 25, 28)
,( 26, 29),( 27, 33),( 28, 34),( 29, 35)
,( 30, 36),( 31, 15),( 32, 16),( 33, 37)
,( 34, 38),( 35, 39),( 36, 30),( 37, 31)
,( 38, 44),( 39, 45),( 40, 46),( 41, 47)
,( 42, 48),( 43, 49),( 44, 50),( 45, 51)
,( 46, 52),( 47, 53),( 48, 54),( 49, 56)
,( 50, 57),( 51, 59),( 52, 60),( 53, 19)
,( 54, 61),( 55, 55),( 56, 58),( 57, 62)
,( 58, 63),( 59, 20),( 60, 68),( 61, 69)
,( 64, 64),( 65, 65),( 66, 66),( 67, 67)
,( 69, 32),( 70, 43),( 71, 42),(-1,-3000)

-- state  3
,(-1,-3000)
-- state  4
,(-1,-2)
-- state  5
,( 3, 76),( 4, 78)
,( 5, 82),( 6, 80),( 7, 81),( 8, 79)
,( 10, 75),(-1,-3000)
-- state  6
,( 4, 84),(-1,-3000)

-- state  7
,( 5, 82),(-1,-3000)
-- state  8
,( 5, 82),(-1,-3000)

-- state  9
,( 6, 87),(-1,-3000)
-- state  10
,( 6, 88),(-1,-3000)

-- state  11
,( 3, 76),( 4, 78),( 5, 82),( 6, 80)
,( 7, 81),( 8, 79),( 10, 75),(-1,-3000)

-- state  12
,( 4, 91),( 5, 82),( 6, 80),( 7, 81)
,(-1,-3000)
-- state  13
,( 4, 78),( 5, 82),( 8, 79)
,(-1,-3000)
-- state  14
,( 4, 95),(-1,-3000)
-- state  15
,( 4, 91)
,( 5, 82),( 6, 80),( 7, 81),(-1,-3000)

-- state  16
,( 4, 97),(-1,-3000)
-- state  17
,( 3, 76),( 4, 78)
,( 5, 82),( 6, 80),( 7, 81),( 8, 79)
,( 10, 75),(-1,-3000)
-- state  18
,(-1,-21)
-- state  19
,( 9, 99)
,(-1,-3000)
-- state  20
,( 6, 100),(-1,-3000)
-- state  21
,( 72, 101)
,(-1,-3000)
-- state  22
,(-1,-24)
-- state  23
,(-1,-25)
-- state  24
,(-1,-26)

-- state  25
,(-1,-27)
-- state  26
,(-1,-28)
-- state  27
,(-1,-29)
-- state  28
,(-1,-30)

-- state  29
,(-1,-31)
-- state  30
,(-1,-32)
-- state  31
,(-1,-33)
-- state  32
,(-1,-34)

-- state  33
,(-1,-35)
-- state  34
,(-1,-36)
-- state  35
,(-1,-37)
-- state  36
,(-1,-38)

-- state  37
,(-1,-39)
-- state  38
,(-1,-40)
-- state  39
,(-1,-41)
-- state  40
,(-1,-42)

-- state  41
,(-1,-43)
-- state  42
,(-1,-44)
-- state  43
,(-1,-45)
-- state  44
,(-1,-63)

-- state  45
,(-1,-64)
-- state  46
,(-1,-65)
-- state  47
,(-1,-66)
-- state  48
,(-1,-67)

-- state  49
,(-1,-68)
-- state  50
,(-1,-69)
-- state  51
,(-1,-70)
-- state  52
,(-1,-71)

-- state  53
,(-1,-46)
-- state  54
,(-1,-47)
-- state  55
,(-1,-48)
-- state  56
,(-1,-49)

-- state  57
,(-1,-50)
-- state  58
,(-1,-51)
-- state  59
,(-1,-52)
-- state  60
,(-1,-53)

-- state  61
,(-1,-54)
-- state  62
,(-1,-55)
-- state  63
,(-1,-56)
-- state  64
,(-1,-57)

-- state  65
,(-1,-58)
-- state  66
,(-1,-59)
-- state  67
,(-1,-60)
-- state  68
,(-1,-61)

-- state  69
,(-1,-62)
-- state  70
,(-1,-3)
-- state  71
,( 2, 102),(-1,-3000)

-- state  72
,(-1,-6)
-- state  73
,(-1,-72)
-- state  74
,(-1,-73)
-- state  75
,(-1,-74)

-- state  76
,(-1,-75)
-- state  77
,(-1,-79)
-- state  78
,(-1,-80)
-- state  79
,(-1,-81)

-- state  80
,(-1,-84)
-- state  81
,(-1,-85)
-- state  82
,( 74, 103),(-1,-3000)

-- state  83
,( 73, 104),(-1,-3000)
-- state  84
,( 73, 105),(-1,-3000)

-- state  85
,( 73, 106),(-1,-3000)
-- state  86
,(-1,-11)
-- state  87
,(-1,-12)

-- state  88
,(-1,-13)
-- state  89
,( 73, 107),(-1,-3000)
-- state  90
,(-1,-76)

-- state  91
,(-1,-77)
-- state  92
,(-1,-78)
-- state  93
,( 73, 108),(-1,-3000)

-- state  94
,( 73, 109),(-1,-3000)
-- state  95
,(-1,-17)
-- state  96
,( 73, 110)
,(-1,-3000)
-- state  97
,(-1,-19)
-- state  98
,(-1,-20)
-- state  99
,(-1,-22)

-- state  100
,(-1,-23)
-- state  101
,(-1,-7)
-- state  102
,(-1,-4)
-- state  103
,( 4, 111)
,( 62, 112),( 63, 113),( 68, 114),(-1,-3000)

-- state  104
,( 4, 116),(-1,-3000)
-- state  105
,( 5, 82),(-1,-3000)

-- state  106
,( 4, 118),(-1,-3000)
-- state  107
,( 4, 119),(-1,-3000)

-- state  108
,( 4, 120),(-1,-3000)
-- state  109
,( 4, 121),(-1,-3000)

-- state  110
,( 4, 122),(-1,-3000)
-- state  111
,(-1,-86)
-- state  112
,(-1,-87)

-- state  113
,(-1,-88)
-- state  114
,(-1,-89)
-- state  115
,( 73, 124),( 75, 123)
,(-1,-3000)
-- state  116
,(-1,-8)
-- state  117
,(-1,-9)
-- state  118
,(-1,-10)

-- state  119
,(-1,-14)
-- state  120
,(-1,-15)
-- state  121
,(-1,-16)
-- state  122
,(-1,-18)

-- state  123
,(-1,-82)
-- state  124
,( 4, 125),(-1,-3000)
-- state  125
,( 75, 126)
,(-1,-3000)
-- state  126
,(-1,-83)
);
--  The offset vector
SHIFT_REDUCE_OFFSET : array (0.. 126) of Integer :=
( 0,
 1, 3, 64, 65, 66, 74, 76, 78, 80, 82,
 84, 92, 97, 101, 103, 108, 110, 118, 119, 121,
 123, 125, 126, 127, 128, 129, 130, 131, 132, 133,
 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
 144, 145, 146, 147, 148, 149, 150, 151, 152, 153,
 154, 155, 156, 157, 158, 159, 160, 161, 162, 163,
 164, 165, 166, 167, 168, 169, 170, 171, 172, 173,
 174, 176, 177, 178, 179, 180, 181, 182, 183, 184,
 185, 186, 188, 190, 192, 194, 195, 196, 197, 199,
 200, 201, 202, 204, 206, 207, 209, 210, 211, 212,
 213, 214, 215, 220, 222, 224, 226, 228, 230, 232,
 234, 235, 236, 237, 238, 241, 242, 243, 244, 245,
 246, 247, 248, 249, 251, 253);

   package yy is

       -- the size of the value and state stacks
       stack_size : constant Natural := 300;

       -- subtype rule         is natural;
       subtype parse_state  is natural;
       -- subtype nonterminal  is integer;

       -- encryption constants
       default           : constant := -1;
       first_shift_entry : constant :=  0;
       accept_code       : constant := -3001;
       error_code        : constant := -3000;

       -- stack data used by the parser
       tos                : natural := 0;
    package yy_tokens              renames
      Ma_Syntax_Tokens;
       value_stack        : array(0..stack_size) of yy_tokens.yystype;
       state_stack        : array(0..stack_size) of parse_state;

       -- current input symbol and action the parser is on
       action             : integer;
       rule_id            : Ma_Syntax_Goto.rule;
       input_symbol       : yy_tokens.token;


       -- error recovery flag
       error_flag : natural := 0;
          -- indicates  3 - (number of valid shifts after an error occurs)

       look_ahead : boolean := true;
       index      : integer;

    end yy;

end Ma_Syntax_Shift_Reduce;
